# Liquid Volume 0.2.0-dev

A cautious LSPosed / modern LibXposed API 102 development scaffold for a Samsung One UI volume-panel appearance module.

## Target profile supplied by the user
- Device: Samsung Galaxy S23+ (SM-S916B/DS)
- Firmware family reported: S916BXXUAGZIF, CSC EUX
- Android reported: 17 / API 37
- LSPosed reported: 2.2.1 (7936), API 102, arm64-v8a

These values are user-reported and have not been independently verified by this project.

## Phase 1 findings from the supplied SystemUI.apk
The APK contains multiple volume UI paths. Confirmed class names include:
- `com.android.systemui.volume.SamsungVolumeDialogImpl`
- `com.android.systemui.volume.VolumePanelImpl`
- `com.android.systemui.volume.VolumeDialogControllerImpl`
- `com.android.systemui.volume.panel.ui.viewmodel.VolumePanelViewModel`
- `com.android.systemui.volume.dialog.ui.binder.VolumeDialogViewBinder`
- `com.android.systemui.volume.dialog.sliders.ui.VolumeDialogSliderViewBinder`
- `com.android.systemui.volume.dialog.ui.viewmodel.VolumeDialogViewModel`
- `com.android.systemui.volume.dialog.sliders.ui.viewmodel.VolumeDialogSliderViewModel`
- `com.samsung.systemui.splugins.volume.VolumePanelState`
- `com.samsung.systemui.splugins.volume.VolumePanelAction`

Useful method signatures confirmed in the DEX method table:
- `SamsungVolumeDialogImpl.init(int, VolumeDialog.Callback)` and `destroy()`
- `VolumePanelImpl.dispatch(VolumePanelAction, boolean)`
- `VolumePanelImpl.getVolumePanelCurrentState()`
- `VolumePanelImpl.recreateVolumePanelForNewConfig()`
- `VolumeDialogViewBinder.bind(CoroutineScope, Dialog, boolean)`

See `dex-method-inventory.txt` for the extracted method inventory. DEX presence and signatures are confirmed, but runtime call order, view hierarchy, and the exact displayed dialog implementation are not yet confirmed.

## Safety and implementation status
This build remains diagnostic-only. It scans the target classes when `com.android.systemui` loads and logs which classes are present. It does not hook methods, replace views, change audio streams, or modify SystemUI files.

The intended implementation strategy is to decorate the existing dialog/view hierarchy while leaving Samsung's volume controller and slider listeners intact. Real background blur will be attempted only through supported Android window blur APIs when the device compositor reports support, with a translucent-tint fallback. No system partition flashing is part of this project.

## Build
Open this directory in Android Studio and build `app:assembleDebug`. A Gradle wrapper is not included yet, and this environment did not have Gradle installed, so this source has not been compiled or packaged here.

Install the resulting debug APK normally, enable the module in LSPosed, and scope it only to `com.android.systemui`. After reboot, inspect LSPosed logs for tag `LiquidVolume`.

Do not enable any future UI hooks until the runtime log confirms which implementation is active on the actual device. Keep a way to disable the module from LSPosed if SystemUI crashes.

## Compiler sans Android Studio avec GitHub Actions

1. Créer un dépôt GitHub (privé possible) et envoyer **le contenu** du dossier `LiquidVolume` à la racine du dépôt, y compris `.github/workflows/build-apk.yml`.
2. Dans GitHub, ouvrir **Actions > Build Liquid Volume APK > Run workflow**. Un push sur `main` ou `master` lance aussi la compilation.
3. Après succès, ouvrir le run et télécharger l'artifact `LiquidVolume-debug-apk`, qui contient `app-debug.apk`.
4. Si la compilation échoue, ouvrir l'étape rouge **Build debug APK** et partager les dernières lignes du journal. La compilation n'a pas été vérifiée localement.

Cette version est uniquement **diagnostique**. Elle ne modifie pas encore le panneau de volume. Ne pas flasher le ZIP avec KernelSU : installer l'APK Android généré, puis activer le scope `com.android.systemui` dans LSPosed.
